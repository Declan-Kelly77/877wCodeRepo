/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// flywheel             motor         9               
// roller               motor         10              
// ds                   motor         8               
// motorL               motor         5               
// motorR               motor         4               
// Motor_L2             motor         11              
// Motor_R2             motor         12              
// egl                  motor         14              
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"
#include <cmath>
#include <iostream>
#include <iomanip>

using namespace vex;

// A global instance of competition
competition Competition;

// define your global instances of motors and other devices here

/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/

void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  // All activities that occur before the competition starts
  // Example: clearing encoders, setting servo positions, ...
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/
// right side code
 void fire(double power){
  vex::motor lucy(vex::PORT3, vex::gearSetting::ratio18_1, true);
  flywheel.setVelocity(82, percent);
  flywheel.spin(forward, power, percent);
  wait(4, seconds);
  lucy.setVelocity(100, percent);
  lucy.spin(forward);

}

void autonomous(void) {
// ..........................................................................
  // Motor Setup
  motor_group rightDrive(motorR, Motor_R2);
  motor_group leftDrive(motorL, Motor_L2);
  motor_group fullDrive(motorL, motorR, Motor_L2, Motor_R2);
  drivetrain DriveTrain(rightDrive, leftDrive, 12.56, 1, 9.44882, distanceUnits::in);
  vex::motor Roller(vex::PORT10, vex::gearSetting::ratio18_1, false);
  leftDrive.setVelocity(-80, percent);
  rightDrive.setVelocity(80, percent);



//right Side
fullDrive.spinFor(forward, 0.25, seconds);
//Roller.spinFor(forward, 0.25, seconds);
fire(100);
//DriveTrain.driveFor(10, inches);





//left side auton 



  // Speed Setup | -100 for opposite direction
 // fullDrive.setVelocity(85, percent);
  //DriveTrain.setDriveVelocity(75, percent);
  
  // Drive Setup
  //fullDrive.spinFor(forward, 0.25, seconds);
  
  //roller.spinFor(0.5, seconds);
  //DriveTrain.driveFor(-5, inches);
  //DriveTrain.turnFor(90, degrees);
  //fire(55);
  }

// ..........................................................................
/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void usercontrol(void) {
  // User control code here, inside the loop
  while (1) {
    // This is the main execution loop for the user control program.
    // Each time through the loop your program should update motor + servo
    // values based on feedback from the joysticks.
      
  // ........................................................................
    
        // PORT SETUP INFORMATION
          /* port 5 front left motor
             port 11 back left motor
             port 4 front right motor
             port 12 back right motor
             port 16 GPS sensor Not important right now
             ------------------------
             port 9 flywheel
             port 10 game element roller
             port 8 disc smasher
             port 3 yellow disc intake
          */
        
        // RECENT CHANGES/NOTES
          /* Version 1.26
             Date 12/17/2022

             CHANGES 
             (+) 
             (+) 
             (+) 

             NOTES
             (*) Consider using a gyro to aid in turning https://www.vexforum.com/t/vexcode-motor-groups-and-drivetrain-example/69161
             (*) Temperature checking system still a work in progress
             (*) Configure GPS sensor offset by also looking at the example (Check if we have a gps sensor)  
          */
  
  
  // Device Contructors Settings
  vex::motor lucy(vex::PORT3, vex::gearSetting::ratio18_1, true);
  vex::motor lucy2(vex::PORT3, vex::gearSetting::ratio18_1, false);
  vex::controller con(vex::controllerType::primary);


  // Motor Grouping Settings
  
  // Left side of the robot
  motor_group leftDrive(motorL, Motor_L2);
  
  //Right side of the robot
  motor_group rightDrive(motorR, Motor_R2);  

  // Speed Settings
  lucy.setVelocity(100, percent);
  //flywheel.setVelocity(100,percent);
  roller.setVelocity(100, percent);
  motorL.setVelocity(100, percent);
  motorL.setVelocity(100, percent);
  Motor_R2.setVelocity(100, percent);
  Motor_L2.setVelocity(100, percent);



  // Speed Drivetrain Settings
  double turnImportance = 1;


  // During Drivetrain Code
  double turnVal = Controller1.Axis3.position();
  double forwardVal = Controller1.Axis1.position();
  double turnVolts = turnVal * 0.12;
  double forwadVolts = forwardVal * 0.12 * (1 - (std::abs(turnVolts)/12) * turnImportance);


  // During Drivetrain Code 
  leftDrive.spin(forward, forwadVolts - turnVolts, voltageUnits::volt);
  rightDrive.spin(forward, forwadVolts + turnVolts, voltageUnits::volt);

  
  // Game Element Roller Mover
  if (Controller1.ButtonA.pressing())
  {
  roller.spin(vex::directionType::fwd);
  }
  else
  {
  roller.stop();
  }




  // Disc Slapper Intake
  /* if(Controller1.ButtonB.pressing())
  {
  ds.setVelocity(100, percent);
  ds.spinFor(forward, 40, degrees);
  wait(100, msec);
  ds.setVelocity(50, percent);
  ds.spinFor(reverse, 40, degrees);
  ds.stop();
  }
  else
  {
  ds.stop();
  }
  */

  egl.setBrake(hold);
  // Endgame prep
  egl.setVelocity(15, percent);
  egl.stop();
  // Endgame launcher
  //egl.setVelocity(100, percent);

  if (Controller1.ButtonB.pressing()){
  egl.spin(vex::directionType::rev);
  wait(3, seconds);
  egl.spin(forward);
  wait(3,seconds);
  }
  else
  {
  egl.stop();
  }
  

  // Yellow Disc Intake
  if (Controller1.ButtonL1.pressing())
  {
  lucy.spin(vex::directionType::rev, 100, percent);
  }
  else if (Controller1.ButtonL2.pressing())
  {
  lucy.spin(vex::directionType::fwd,100, percent);
  }
  else
  {
  lucy.stop();
  }
  
    
  // Disc Flywheel
  if (Controller1.ButtonR1.pressing())
  {
  flywheel.spin(vex::directionType::fwd, 57, percent);
  }
  else if (Controller1.ButtonR2.pressing())
  {
  flywheel.spin(vex::directionType::rev, 25, percent);
  } 
  else
  {
  flywheel.stop();
  }


 if (Controller1.ButtonX.pressing())
  {
  ds.stop(brake);
  ds.stop(brake);
  flywheel.stop(brake);
  lucy.stop(brake);
  roller.stop(brake);
  }
  
  


  
  // High Goal Targeting System
  //if (Controller1.ButtonX.pressing())
  //{
  // gps::setLocatio
  //}



  // Motor Temperature Setup | Motors overheat at 55C
  Brain.Screen.setPenColor(ClrDarkGoldenrod);
  Brain.Screen.setFont(mono20);
  Brain.Screen.setFillColor(white);

  Brain.Screen.printAt(0, 20, "FRONT LEFT MOTOR - %f", motorL.temperature(temperatureUnits::celsius));
  Brain.Screen.printAt(0, 40, "BACK LEFT MOTOR - %f", Motor_L2.temperature(temperatureUnits::celsius));
  Brain.Screen.printAt(0, 60, "FRONT RIGHT MOTOR - %f", motorR.temperature(temperatureUnits::celsius));
  Brain.Screen.printAt(0, 80, "BACK RIGHT MOTOR - %f", Motor_R2.temperature(temperatureUnits::celsius));
  Brain.Screen.printAt(0,100, "FLYWHEEL - %f", flywheel.temperature(temperatureUnits::celsius));

  Brain.Screen.setFont(monoXXL);
  Brain.Screen.printAt(0,160, "LUCY - 877W ");




  // ........................................................................

    wait(20, msec); // Sleep the task for a short amount of time to
                    // prevent wasted resources.
  }
}

//
// Main will set up the competition functions and callbacks.
//
int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
  }
}





