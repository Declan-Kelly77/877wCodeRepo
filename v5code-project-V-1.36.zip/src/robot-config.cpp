#include "vex.h"

using namespace vex;
using signature = vision::signature;
using code = vision::code;

// A global instance of brain used for printing to the V5 Brain screen
brain  Brain;

// VEXcode device constructors
controller Controller1 = controller(primary);
motor flywheel = motor(PORT9, ratio6_1, true);
motor roller = motor(PORT10, ratio18_1, false);
motor ds = motor(PORT8, ratio18_1, true);
motor motorR = motor(PORT4, ratio18_1, false);
motor Motor_L2 = motor(PORT11, ratio18_1, true);
motor Motor_R2 = motor(PORT12, ratio18_1, false);
rotation flywheela = rotation(PORT15, false);
/*vex-vision-config:begin*/
vision Eye = vision (PORT18, 50);
/*vex-vision-config:end*/
motor Thruster = motor(PORT7, ratio18_1, false);
inertial Dir = inertial(PORT14);
motor motorL = motor(PORT5, ratio18_1, true);
motor egl = motor(PORT13, ratio18_1, false);

// VEXcode generated functions
// define variable for remote controller enable/disable
bool RemoteControlCodeEnabled = true;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void vexcodeInit( void ) {
  // nothing to initialize
}