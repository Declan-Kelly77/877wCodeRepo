using namespace vex;

extern brain Brain;

using signature = vision::signature;

// VEXcode devices
extern controller Controller1;
extern motor flywheel;
extern motor roller;
extern motor ds;
extern motor motorR;
extern motor Motor_L2;
extern motor Motor_R2;
extern rotation flywheela;
extern signature Eye__REDGOAL;
extern signature Eye__BLUEGOAL;
extern signature Eye__AKARSH;
extern signature Eye__SIG_4;
extern signature Eye__SIG_5;
extern signature Eye__SIG_6;
extern signature Eye__SIG_7;
extern vision Eye;
extern motor Thruster;
extern inertial Dir;
extern motor motorL;
extern motor egl;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void  vexcodeInit( void );